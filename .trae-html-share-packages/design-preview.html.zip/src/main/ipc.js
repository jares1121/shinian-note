import { ipcMain, BrowserWindow, dialog, app } from 'electron'
import { writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import { notesRepo, tagsRepo, backupDB, restoreDB } from './db.js'

// 任何数据变更后广播给所有窗口（主窗口 + 速记窗），各窗口自行刷新
function broadcast() {
  for (const win of BrowserWindow.getAllWindows()) {
    win.webContents.send('notes:changed')
  }
}

// Windows 文件名非法字符替换
function safeName(s) {
  return (s || '无标题').replace(/[\\/:*?"<>|\r\n]+/g, '_').slice(0, 50)
}

export function registerIpc() {
  // filter: { keyword?, tagId? }，支持搜索 + 标签筛选
  ipcMain.handle('notes:list', (_e, filter) => notesRepo.list(filter ?? {}))

  ipcMain.handle('notes:create', (_e, content) => {
    const note = notesRepo.create(content ?? '')
    broadcast()
    return note
  })

  ipcMain.handle('notes:update', (_e, id, content) => {
    const note = notesRepo.update(id, content ?? '')
    broadcast()
    return note
  })

  ipcMain.handle('notes:delete', (_e, id) => {
    notesRepo.remove(id)
    broadcast()
  })

  ipcMain.handle('notes:setTags', (_e, id, names) => {
    const note = notesRepo.setTags(id, Array.isArray(names) ? names : [])
    broadcast()
    return note
  })

  ipcMain.handle('tags:list', () => tagsRepo.list())

  // 设置/取消提醒（remindAt 毫秒时间戳，null 取消）
  ipcMain.handle('notes:setReminder', (_e, id, remindAt) => {
    const note = notesRepo.setReminder(id, remindAt)
    broadcast()
    return note
  })

  ipcMain.handle('notes:stats', () => notesRepo.stats())

  // 导出单条笔记为 Markdown（返回 true/false，取消返回 null）
  ipcMain.handle('notes:exportOne', async (e, id) => {
    const note = notesRepo.get(id)
    if (!note) return null
    const win = BrowserWindow.fromWebContents(e.sender)
    const { canceled, filePath } = await dialog.showSaveDialog(win, {
      title: '导出笔记',
      defaultPath: `${safeName(note.title)}.md`,
      filters: [{ name: 'Markdown', extensions: ['md'] }]
    })
    if (canceled || !filePath) return null
    writeFileSync(filePath, note.content, 'utf8')
    return true
  })

  // 导出全部笔记到所选文件夹，每条一个 .md（返回条数，取消返回 null）
  ipcMain.handle('notes:exportAll', async (e) => {
    const win = BrowserWindow.fromWebContents(e.sender)
    const { canceled, filePaths } = await dialog.showOpenDialog(win, {
      title: '选择导出文件夹',
      properties: ['openDirectory', 'createDirectory']
    })
    if (canceled || !filePaths[0]) return null
    const notes = notesRepo.list()
    for (const n of notes) {
      const d = new Date(n.createdAt)
      const p = (x) => String(x).padStart(2, '0')
      const day = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
      writeFileSync(join(filePaths[0], `${day}_${n.id}_${safeName(n.title)}.md`), n.content, 'utf8')
    }
    return notes.length
  })

  // 备份数据库到所选文件
  ipcMain.handle('backup:create', async (e) => {
    const win = BrowserWindow.fromWebContents(e.sender)
    const day = new Date().toISOString().slice(0, 10)
    const { canceled, filePath } = await dialog.showSaveDialog(win, {
      title: '备份数据库',
      defaultPath: `shinian-backup-${day}.db`,
      filters: [{ name: '拾念备份', extensions: ['db'] }]
    })
    if (canceled || !filePath) return null
    await backupDB(filePath)
    return true
  })

  // 从备份文件恢复（覆盖当前库）
  ipcMain.handle('backup:restore', async (e) => {
    const win = BrowserWindow.fromWebContents(e.sender)
    const { canceled, filePaths } = await dialog.showOpenDialog(win, {
      title: '选择备份文件（将覆盖当前全部数据）',
      filters: [{ name: '拾念备份', extensions: ['db'] }],
      properties: ['openFile']
    })
    if (canceled || !filePaths[0]) return null
    restoreDB(filePaths[0])
    broadcast()
    return true
  })

  // 保存粘贴的图片到 userData/images，返回自定义协议 URL
  ipcMain.handle('images:save', (_e, bytes, mime) => {
    const ext =
      { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' }[mime] ??
      'png'
    const dir = join(app.getPath('userData'), 'images')
    mkdirSync(dir, { recursive: true })
    const name = `${Date.now()}-${randomUUID().slice(0, 8)}.${ext}`
    writeFileSync(join(dir, name), bytes)
    return `shinian-img:///${name}`
  })

  // 速记窗请求隐藏自己
  ipcMain.handle('quick:hide', (e) => {
    BrowserWindow.fromWebContents(e.sender)?.hide()
  })
}
