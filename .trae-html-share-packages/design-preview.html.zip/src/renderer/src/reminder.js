import { createApp } from 'vue'
import ReminderApp from './ReminderApp.vue'
import './style.css'

const savedTheme = localStorage.getItem('shinian-theme')
if (
  savedTheme === 'dark' ||
  (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)
) {
  document.documentElement.classList.add('dark')
}

createApp(ReminderApp).mount('#app')
