<script setup>
import { ref, computed, nextTick } from 'vue'

const props = defineProps({
  tags: { type: Array, default: () => [] }
})
const emit = defineEmits(['change'])

const input = ref('')
const editing = ref(false)
const inputEl = ref(null)

const names = computed(() => props.tags.map((t) => t.name))

function startEdit() {
  editing.value = true
  nextTick(() => inputEl.value?.focus())
}

function commit() {
  const v = input.value.trim()
  if (v && !names.value.includes(v)) {
    emit('change', [...names.value, v])
  }
  input.value = ''
  editing.value = false
}

function remove(name) {
  emit(
    'change',
    names.value.filter((n) => n !== name)
  )
}

function onKeydown(e) {
  if (e.key === 'Enter') {
    commit()
  } else if (e.key === 'Escape') {
    input.value = ''
    editing.value = false
  } else if (e.key === 'Backspace' && !input.value && names.value.length) {
    // 输入框为空时按退格，删掉最后一个标签
    remove(names.value[names.value.length - 1])
  }
}
</script>

<template>
  <div class="flex items-center gap-1.5 flex-wrap">
    <span
      v-for="tag in tags"
      :key="tag.id"
      class="inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded-full bg-neutral-100 text-neutral-600 dark:bg-neutral-700 dark:text-neutral-300"
    >
      #{{ tag.name }}
      <button
        class="hover:text-red-500 transition"
        title="移除标签"
        @click="remove(tag.name)"
      >
        ×
      </button>
    </span>
    <input
      v-if="editing"
      ref="inputEl"
      v-model="input"
      type="text"
      placeholder="标签名，回车确认"
      class="w-28 px-2 py-0.5 text-xs rounded-md bg-neutral-100 outline-none focus:ring-1 focus:ring-neutral-400 dark:bg-neutral-700"
      @keydown="onKeydown"
      @blur="commit"
    />
    <button
      v-else
      class="px-2 py-0.5 text-xs rounded-full text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
      @click="startEdit"
    >
      + 标签
    </button>
  </div>
</template>
