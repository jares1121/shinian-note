<script setup>
import { ref, computed, onBeforeUnmount, nextTick } from 'vue'
import { marked } from 'marked'
import TagEditor from './TagEditor.vue'
import Icon from './Icon.vue'

marked.setOptions({ breaks: true, gfm: true })

const props = defineProps({
  note: { type: Object, required: true }
})
const emit = defineEmits(['saved', 'deleted'])

const draft = ref(props.note.content)
const dirty = ref(false)
const saving = ref(false)
const lastSavedAt = ref(null)
const mode = ref('edit') // 'edit' | 'preview'
const textareaRef = ref(null)
let timer = null

const previewHtml = computed(() => marked.parse(draft.value || ''))

function onInput() {
  dirty.value = true
  clearTimeout(timer)
  timer = setTimeout(save, 400)
}

// 切走/关闭前把未保存的内容立即落库
async function flush() {
  clearTimeout(timer)
  if (!dirty.value) return
  await save()
}

async function save() {
  if (!dirty.value) return
  dirty.value = false
  saving.value = true
  await window.api.updateNote(props.note.id, draft.value)
  saving.value = false
  lastSavedAt.value = new Date()
  emit('saved')
}

async function toggleMode() {
  if (mode.value === 'edit') {
    await flush() // 进预览前先落库
    mode.value = 'preview'
  } else {
    mode.value = 'edit'
  }
}

async function onTagsChange(names) {
  await window.api.setNoteTags(props.note.id, names)
  emit('saved')
}

// datetime-local 需要的格式：YYYY-MM-DDTHH:MM（本地时区）
const remindInput = computed(() => {
  if (!props.note.remindAt) return ''
  const d = new Date(props.note.remindAt)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
})

async function onRemindPick(e) {
  if (!e.target.value) return
  await window.api.setNoteReminder(props.note.id, new Date(e.target.value).getTime())
  emit('saved')
}

async function clearReminder() {
  await window.api.setNoteReminder(props.note.id, null)
  emit('saved')
}

// 导出为 Markdown 前先落库，保证导出的是最新内容
async function exportNote() {
  await flush()
  await window.api.exportNote(props.note.id)
}

// 粘贴图片：存到 userData/images 后在光标处插入 Markdown 图片链接
async function onPaste(e) {
  const images = [...(e.clipboardData?.items ?? [])].filter(
    (it) => it.kind === 'file' && it.type.startsWith('image/')
  )
  if (images.length === 0) return
  e.preventDefault()
  for (const it of images) {
    const file = it.getAsFile()
    const bytes = new Uint8Array(await file.arrayBuffer())
    const url = await window.api.saveImage(bytes, file.type)
    insertAtCursor(`![图片](${url})\n`)
  }
}

function insertAtCursor(text) {
  const el = textareaRef.value
  if (!el) {
    draft.value += text
    onInput()
    return
  }
  const start = el.selectionStart ?? draft.value.length
  const end = el.selectionEnd ?? start
  draft.value = draft.value.slice(0, start) + text + draft.value.slice(end)
  onInput() // 走 400ms 防抖自动保存
  nextTick(() => {
    el.focus()
    el.selectionStart = el.selectionEnd = start + text.length
  })
}

async function remove() {
  if (!confirm('确定删除这条笔记吗？删除后无法恢复。')) return
  clearTimeout(timer)
  dirty.value = false
  await window.api.deleteNote(props.note.id)
  emit('deleted', props.note.id)
}

function fmtTime(d) {
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`
}

function fmtDate(ts) {
  const d = new Date(ts)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${fmtTime(d)}`
}

onBeforeUnmount(flush)
</script>

<template>
  <div class="h-full flex flex-col">
    <div class="px-4 py-2 flex items-center justify-between border-b border-neutral-200/80 text-sm text-neutral-400 dark:border-neutral-800">
      <div class="flex items-center gap-3 text-xs">
        <span class="flex items-center gap-1.5">
          <Icon name="clock" cls="w-3.5 h-3.5" />
          {{ fmtDate(note.createdAt) }}
        </span>
        <span class="flex items-center gap-1.5">
          <span class="w-1.5 h-1.5 rounded-full" :class="saving ? 'bg-amber-500 animate-pulse' : 'bg-green-500'"></span>
          <template v-if="saving">保存中…</template>
          <template v-else-if="lastSavedAt">已保存 {{ fmtTime(lastSavedAt) }}</template>
          <template v-else>自动保存</template>
        </span>
      </div>
      <div class="flex items-center gap-1">
        <button
          class="flex items-center gap-1 px-2 py-1 rounded-md text-xs hover:bg-neutral-100 dark:hover:bg-neutral-800 transition"
          :title="mode === 'edit' ? '预览 Markdown' : '返回编辑'"
          @click="toggleMode"
        >
          <Icon :name="mode === 'edit' ? 'eye' : 'pencil'" cls="w-3.5 h-3.5" />
          {{ mode === 'edit' ? '预览' : '编辑' }}
        </button>
        <button
          class="flex items-center gap-1 px-2 py-1 rounded-md text-xs hover:bg-neutral-100 dark:hover:bg-neutral-800 transition"
          title="导出为 Markdown 文件"
          @click="exportNote"
        >
          <Icon name="export" cls="w-3.5 h-3.5" />
          导出
        </button>
        <button
          class="flex items-center gap-1 px-2 py-1 rounded-md text-xs hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/30 transition"
          title="删除这条笔记"
          @click="remove"
        >
          <Icon name="trash" cls="w-3.5 h-3.5" />
          删除
        </button>
      </div>
    </div>

    <div class="px-4 py-2 flex items-center gap-2 border-b border-neutral-200/80 dark:border-neutral-800">
      <Icon name="tag" cls="w-4 h-4 text-neutral-400 shrink-0" />
      <TagEditor :tags="note.tags" @change="onTagsChange" />
    </div>

    <div class="px-4 py-1.5 flex items-center gap-2 border-b border-neutral-200/80 text-sm dark:border-neutral-800">
      <Icon name="bell" cls="w-4 h-4 text-neutral-400 shrink-0" />
      <input
        type="datetime-local"
        :value="remindInput"
        class="px-2 py-0.5 text-xs rounded-md bg-neutral-100 text-neutral-600 outline-none focus:ring-2 focus:ring-amber-500/40 dark:bg-neutral-800 dark:text-neutral-300 dark:[color-scheme:dark]"
        @change="onRemindPick"
      />
      <template v-if="note.remindAt">
        <span
          v-if="note.reminded"
          class="text-[11px] px-1.5 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300"
        >
          已于 {{ fmtDate(note.remindAt) }} 提醒
        </span>
        <span
          v-else
          class="text-[11px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300"
        >
          {{ fmtDate(note.remindAt) }}
        </span>
        <button
          class="text-[11px] px-2 py-0.5 rounded-md text-neutral-400 hover:text-red-500 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition"
          @click="clearReminder"
        >
          清除
        </button>
      </template>
      <span v-else class="text-[11px] text-neutral-300 dark:text-neutral-600">设置提醒</span>
    </div>

    <div class="flex-1 min-h-0 overflow-y-auto">
      <textarea
        v-if="mode === 'edit'"
        ref="textareaRef"
        v-model="draft"
        class="block w-full h-full max-w-3xl mx-auto px-8 py-6 resize-none outline-none bg-transparent text-[15px] leading-7"
        placeholder="开始记录…支持 Markdown 语法，可直接粘贴图片"
        autofocus
        @input="onInput"
        @blur="flush"
        @paste="onPaste"
      ></textarea>
      <div
        v-else
        class="max-w-3xl mx-auto px-8 py-6 text-[15px] md-preview"
        v-html="previewHtml"
      ></div>
    </div>
  </div>
</template>
