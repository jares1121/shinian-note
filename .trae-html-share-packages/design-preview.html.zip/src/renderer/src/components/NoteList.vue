<script setup>
import { computed } from 'vue'

const props = defineProps({
  notes: { type: Array, required: true },
  selectedId: { type: [Number, null], default: null }
})
const emit = defineEmits(['select'])

const DAY = 86400000

function dayLabel(d) {
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()
  const startOfDay = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
  const diff = startOfToday - startOfDay
  if (diff === 0) return '今天'
  if (diff === DAY) return '昨天'
  if (d.getFullYear() === now.getFullYear()) return `${d.getMonth() + 1}月${d.getDate()}日`
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`
}

// 按更新日期分组（notes 已按 updatedAt 倒序）
const groups = computed(() => {
  const result = []
  let current = null
  for (const note of props.notes) {
    const d = new Date(note.updatedAt)
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
    if (!current || current.key !== key) {
      current = { key, label: dayLabel(d), notes: [] }
      result.push(current)
    }
    current.notes.push(note)
  }
  return result
})

function hhmm(ts) {
  const d = new Date(ts)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function snippet(content) {
  // 图片语法显示为占位符，不出现在摘要里
  const text = content
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '[图片]')
    .replace(/\s+/g, ' ')
    .trim()
  return text.length > 40 ? text.slice(0, 40) + '…' : text
}
</script>

<template>
  <ul class="flex-1 overflow-y-auto px-2 pb-2">
    <template v-for="group in groups" :key="group.key">
      <li class="sticky top-0 z-10 px-3 pt-3 pb-1 text-[11px] font-semibold tracking-wider text-neutral-400 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-sm select-none">
        {{ group.label }}
      </li>
      <li
        v-for="note in group.notes"
        :key="note.id"
        class="mx-1 mb-1 px-3 py-2.5 rounded-lg border-l-2 border-transparent cursor-pointer hover:bg-neutral-100 transition dark:hover:bg-neutral-800"
        :class="{ 'bg-amber-50 border-l-amber-500 dark:bg-amber-500/10': note.id === selectedId }"
        @click="emit('select', note.id)"
      >
        <div class="flex items-baseline justify-between gap-2">
          <span class="font-medium text-sm truncate">{{ note.title }}</span>
          <span class="text-[11px] text-neutral-400 shrink-0 tabular-nums">{{ hhmm(note.updatedAt) }}</span>
        </div>
        <p class="mt-0.5 text-xs text-neutral-500 truncate dark:text-neutral-400">{{ snippet(note.content) || '（空）' }}</p>
        <div v-if="note.tags && note.tags.length" class="mt-1.5 flex flex-wrap gap-1">
          <span
            v-for="tag in note.tags"
            :key="tag.id"
            class="px-1.5 py-px text-[11px] rounded bg-neutral-100 text-neutral-500 dark:bg-neutral-700/60 dark:text-neutral-400"
          >
            #{{ tag.name }}
          </span>
        </div>
      </li>
    </template>
    <li v-if="notes.length === 0" class="px-4 py-10 text-center text-sm text-neutral-400">
      没有匹配的笔记
    </li>
  </ul>
</template>
