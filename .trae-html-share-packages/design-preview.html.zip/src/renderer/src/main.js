import { createApp } from 'vue'
import App from './App.vue'
import './style.css'

// 启动时恢复主题，避免闪烁
const savedTheme = localStorage.getItem('shinian-theme')
if (
  savedTheme === 'dark' ||
  (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)
) {
  document.documentElement.classList.add('dark')
}

createApp(App).mount('#app')
