<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import NoteList from './components/NoteList.vue'
import NoteEditor from './components/NoteEditor.vue'
import StatsView from './components/StatsView.vue'
import Icon from './components/Icon.vue'

const notes = ref([])
const tags = ref([])
const selectedId = ref(null)
const keyword = ref('')
const activeTagId = ref(null)
const isDark = ref(document.documentElement.classList.contains('dark'))
const showStats = ref(false)

// ---- 时间筛选 ----
const timeMode = ref('all') // all | today | week | month | custom
const now0 = new Date()
const viewYear = ref(now0.getFullYear())
const viewMonth = ref(now0.getMonth() + 1)
const customFrom = ref('')
const customTo = ref('')
const DAY = 86400000

const timeRange = computed(() => {
  const t = new Date()
  const startOfToday = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime()
  switch (timeMode.value) {
    case 'today':
      return { from: startOfToday, to: startOfToday + DAY }
    case 'week': {
      // 周一为一周开始
      const offset = (t.getDay() + 6) % 7
      return { from: startOfToday - offset * DAY, to: startOfToday + DAY }
    }
    case 'month':
      return {
        from: new Date(viewYear.value, viewMonth.value - 1, 1).getTime(),
        to: new Date(viewYear.value, viewMonth.value, 1).getTime()
      }
    case 'custom': {
      const r = {}
      if (customFrom.value) {
        const [y, m, d] = customFrom.value.split('-').map(Number)
        r.from = new Date(y, m - 1, d).getTime()
      }
      if (customTo.value) {
        const [y, m, d] = customTo.value.split('-').map(Number)
        r.to = new Date(y, m - 1, d).getTime() + DAY
      }
      return r
    }
    default:
      return {}
  }
})

const monthValue = computed(
  () => `${viewYear.value}-${String(viewMonth.value).padStart(2, '0')}`
)

function shiftMonth(delta) {
  const t = new Date(viewYear.value, viewMonth.value - 1 + delta, 1)
  viewYear.value = t.getFullYear()
  viewMonth.value = t.getMonth() + 1
  timeMode.value = 'month'
}

function gotoCurrentMonth() {
  const t = new Date()
  viewYear.value = t.getFullYear()
  viewMonth.value = t.getMonth() + 1
  timeMode.value = 'month'
}

function onMonthPick(e) {
  if (!e.target.value) return
  const [y, m] = e.target.value.split('-').map(Number)
  viewYear.value = y
  viewMonth.value = m
  timeMode.value = 'month'
}

const isCurrentMonth = computed(() => {
  const t = new Date()
  return viewYear.value === t.getFullYear() && viewMonth.value === t.getMonth() + 1
})

const footerText = computed(() =>
  timeMode.value === 'month'
    ? `${viewYear.value}年${viewMonth.value}月 · 共 ${notes.value.length} 条`
    : `共 ${notes.value.length} 条`
)

const selectedNote = computed(
  () => notes.value.find((n) => n.id === selectedId.value) ?? null
)

async function refresh() {
  const filter = {
    keyword: keyword.value.trim(),
    tagId: activeTagId.value,
    ...timeRange.value
  }
  const [noteRows, tagRows] = await Promise.all([
    window.api.listNotes(filter),
    window.api.listTags()
  ])
  notes.value = noteRows
  tags.value = tagRows
}

// 搜索/标签/时间筛选：200ms 防抖查询
let searchTimer = null
watch([keyword, activeTagId, timeRange], () => {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(refresh, 200)
})

async function createNote() {
  const note = await window.api.createNote('')
  await refresh()
  selectedId.value = note.id
}

function selectNote(id) {
  selectedId.value = id
}

function toggleTagFilter(tagId) {
  activeTagId.value = activeTagId.value === tagId ? null : tagId
}

function toggleTheme() {
  isDark.value = !isDark.value
  document.documentElement.classList.toggle('dark', isDark.value)
  localStorage.setItem('shinian-theme', isDark.value ? 'dark' : 'light')
}

// 编辑器自动保存成功后刷新列表（排序/摘要更新）
async function onSaved() {
  await refresh()
}

// 导出全部笔记到文件夹（取消时返回 null，不提示）
async function onExportAll() {
  const count = await window.api.exportAllNotes()
  if (count !== null) alert(`已导出 ${count} 条笔记`)
}

async function onBackup() {
  const ok = await window.api.backupNow()
  if (ok) alert('备份完成')
}

async function onRestore() {
  if (!confirm('恢复会用备份文件覆盖当前全部数据，且无法撤销。确定继续吗？')) return
  const ok = await window.api.restoreBackup()
  if (ok) {
    await refresh()
    selectedId.value = notes.value[0]?.id ?? null
    alert('恢复完成')
  }
}

async function onDeleted(id) {
  await refresh()
  if (selectedId.value === id) {
    selectedId.value = notes.value[0]?.id ?? null
  }
}

// 点击系统提醒通知后跳转：先清筛选保证笔记在列表里，再选中
async function openNote(id) {
  keyword.value = ''
  activeTagId.value = null
  timeMode.value = 'all'
  await refresh()
  selectedId.value = id
}

onMounted(async () => {
  await refresh()
  if (notes.value.length > 0) selectedId.value = notes.value[0].id
  // 速记窗等其他窗口改了数据，主窗口跟着刷新
  window.api.onNotesChanged(refresh)
  window.api.onOpenNote(openNote)
})
</script>

<template>
  <div class="h-screen flex bg-neutral-50 text-neutral-800 select-none dark:bg-neutral-900 dark:text-neutral-200">
    <aside class="w-72 shrink-0 border-r border-neutral-200/80 flex flex-col bg-white dark:bg-neutral-900 dark:border-neutral-800">
      <header class="px-4 pt-4 pb-3 flex items-center justify-between">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center font-bold shadow-sm shadow-amber-500/40 select-none">拾</div>
          <div>
            <h1 class="text-base font-bold leading-5 tracking-wide">拾念</h1>
            <p class="text-[11px] leading-4 text-neutral-400">随手一记 · 拾回思绪</p>
          </div>
        </div>
        <div class="flex items-center gap-1">
          <button
            class="w-8 h-8 rounded-md flex items-center justify-center transition"
            :class="showStats
              ? 'bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400'
              : 'text-neutral-500 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800'"
            title="统计"
            @click="showStats = !showStats"
          >
            <Icon name="chart" />
          </button>
          <button
            class="w-8 h-8 rounded-md flex items-center justify-center text-neutral-500 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800 transition"
            :title="isDark ? '切换到浅色' : '切换到深色'"
            @click="toggleTheme"
          >
            <Icon :name="isDark ? 'sun' : 'moon'" />
          </button>
        </div>
      </header>

      <div class="px-4 pb-3">
        <button
          class="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600 active:scale-[0.98] transition shadow-sm shadow-amber-500/40"
          @click="createNote"
        >
          <Icon name="plus" /> 新建笔记
        </button>
      </div>

      <div class="px-4 pb-3">
        <div class="relative">
          <Icon
            name="search"
            cls="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none"
          />
          <input
            v-model="keyword"
            type="text"
            placeholder="搜索标题和正文…"
            class="w-full pl-8 pr-3 py-1.5 text-sm rounded-lg bg-neutral-100 outline-none placeholder:text-neutral-400 focus:ring-2 focus:ring-amber-500/40 dark:bg-neutral-800 dark:placeholder:text-neutral-500"
          />
        </div>
      </div>

      <div class="px-4 pb-3 space-y-1.5">
        <p class="text-[11px] font-medium tracking-wider text-neutral-400">时间</p>
        <div class="flex gap-1 flex-wrap">
          <button
            v-for="opt in [
              { mode: 'all', label: '全部' },
              { mode: 'today', label: '今天' },
              { mode: 'week', label: '本周' },
              { mode: 'custom', label: '自定义' }
            ]"
            :key="opt.mode"
            class="px-2 py-0.5 text-xs rounded-full transition"
            :class="timeMode === opt.mode
              ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 dark:bg-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-600'"
            @click="timeMode = opt.mode"
          >
            {{ opt.label }}
          </button>
        </div>
        <div class="flex items-center justify-between">
          <button
            class="w-7 h-7 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
            title="上月"
            @click="shiftMonth(-1)"
          >
            ‹
          </button>
          <input
            type="month"
            :value="monthValue"
            class="px-1.5 py-0.5 text-sm rounded bg-transparent cursor-pointer dark:[color-scheme:dark]"
            :class="timeMode === 'month' ? 'font-semibold' : 'text-neutral-400'"
            title="选择月份"
            @change="onMonthPick"
          />
          <button
            class="w-7 h-7 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
            title="下月"
            @click="shiftMonth(1)"
          >
            ›
          </button>
        </div>
        <button
          v-if="timeMode === 'month' && !isCurrentMonth"
          class="w-full px-2 py-0.5 text-xs rounded-full bg-neutral-100 text-neutral-600 hover:bg-neutral-200 dark:bg-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-600 transition"
          @click="gotoCurrentMonth"
        >
          回到本月
        </button>
        <div v-if="timeMode === 'custom'" class="flex items-center gap-1 text-xs text-neutral-400">
          <input
            v-model="customFrom"
            type="date"
            class="flex-1 min-w-0 px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-700 dark:[color-scheme:dark]"
          />
          <span>至</span>
          <input
            v-model="customTo"
            type="date"
            class="flex-1 min-w-0 px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-700 dark:[color-scheme:dark]"
          />
        </div>
      </div>

      <div v-if="tags.length > 0" class="px-4 pb-3">
        <p class="text-[11px] font-medium tracking-wider text-neutral-400 mb-1.5">标签</p>
        <div class="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
          <button
            class="px-2 py-0.5 text-xs rounded-full transition"
            :class="activeTagId === null
              ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 dark:bg-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-600'"
            @click="activeTagId = null"
          >
            全部
          </button>
          <button
            v-for="tag in tags"
            :key="tag.id"
            class="px-2 py-0.5 text-xs rounded-full transition"
            :class="activeTagId === tag.id
              ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 dark:bg-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-600'"
            @click="toggleTagFilter(tag.id)"
          >
            #{{ tag.name }} {{ tag.count }}
          </button>
        </div>
      </div>

      <NoteList :notes="notes" :selected-id="selectedId" @select="selectNote" />

      <footer class="px-4 py-2 text-xs text-neutral-400 border-t border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
        <span>{{ footerText }}</span>
        <span class="flex gap-0.5">
          <button
            class="w-7 h-7 rounded-md flex items-center justify-center hover:bg-neutral-100 hover:text-neutral-600 dark:hover:bg-neutral-800 dark:hover:text-neutral-300 transition"
            title="导出全部笔记为 Markdown 到文件夹"
            @click="onExportAll"
          >
            <Icon name="export" />
          </button>
          <button
            class="w-7 h-7 rounded-md flex items-center justify-center hover:bg-neutral-100 hover:text-neutral-600 dark:hover:bg-neutral-800 dark:hover:text-neutral-300 transition"
            title="备份数据库到文件"
            @click="onBackup"
          >
            <Icon name="backup" />
          </button>
          <button
            class="w-7 h-7 rounded-md flex items-center justify-center hover:bg-neutral-100 hover:text-neutral-600 dark:hover:bg-neutral-800 dark:hover:text-neutral-300 transition"
            title="从备份文件恢复（覆盖当前数据）"
            @click="onRestore"
          >
            <Icon name="restore" />
          </button>
        </span>
      </footer>
    </aside>

    <main class="flex-1 min-w-0 bg-neutral-50 dark:bg-neutral-950">
      <StatsView v-if="showStats" :is-dark="isDark" @close="showStats = false" />
      <template v-else>
        <NoteEditor
          v-if="selectedNote"
          :key="selectedNote.id"
          :note="selectedNote"
          @saved="onSaved"
          @deleted="onDeleted"
        />
        <div v-else class="h-full flex flex-col items-center justify-center text-neutral-400 gap-3">
          <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center text-3xl font-bold shadow-lg shadow-amber-500/30 select-none">拾</div>
          <p class="text-sm">没有选中的笔记</p>
          <p class="text-xs">
            点左上角「新建笔记」开始记录 · 任何窗口下按
            <kbd class="mx-0.5 px-1.5 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-[11px] font-mono">Ctrl+Shift+N</kbd>
            唤起速记
          </p>
        </div>
      </template>
    </main>
  </div>
</template>
