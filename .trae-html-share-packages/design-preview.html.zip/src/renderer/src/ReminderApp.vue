<script setup>
import { ref, onMounted } from 'vue'

const items = ref([])
let audioCtx = null

// 主窗口切换主题后，提醒窗下次显示时同步
function syncTheme() {
  document.documentElement.classList.toggle(
    'dark',
    localStorage.getItem('shinian-theme') === 'dark'
  )
}

function fmt(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getMonth() + 1}月${d.getDate()}日 ${p(d.getHours())}:${p(d.getMinutes())}`
}

// 提示音：Web Audio 合成两声短音，无需音频文件
function beep() {
  try {
    audioCtx ??= new AudioContext()
    const t0 = audioCtx.currentTime
    for (const [freq, start] of [[880, 0], [660, 0.25]]) {
      const osc = audioCtx.createOscillator()
      const gain = audioCtx.createGain()
      osc.connect(gain)
      gain.connect(audioCtx.destination)
      osc.frequency.value = freq
      gain.gain.setValueAtTime(0.001, t0 + start)
      gain.gain.exponentialRampToValueAtTime(0.25, t0 + start + 0.05)
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + start + 0.25)
      osc.start(t0 + start)
      osc.stop(t0 + start + 0.3)
    }
  } catch {
    // 没声音也不影响弹窗本身
  }
}

function open(id) {
  window.reminderApi.open(id)
}

function dismissAll() {
  window.reminderApi.dismissAll()
}

onMounted(async () => {
  items.value = await window.reminderApi.getList()
  if (items.value.length) beep()
  // 主进程追加新提醒时推送最新列表；数量变多再响一次
  window.reminderApi.onList((list) => {
    if (list.length > items.value.length) beep()
    items.value = list
  })
  window.addEventListener('focus', syncTheme)
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') dismissAll()
  })
})
</script>

<template>
  <div class="h-screen flex flex-col bg-white rounded-lg overflow-hidden border-2 border-amber-400 shadow-2xl dark:bg-neutral-800 dark:border-amber-500/60">
    <div
      class="px-3 py-2 bg-amber-500 text-white text-sm flex items-center justify-between select-none"
      style="-webkit-app-region: drag"
    >
      <span class="font-medium"><span class="animate-pulse inline-block">🔔</span> 拾念提醒 · {{ items.length }} 条</span>
      <button
        class="w-6 h-6 rounded hover:bg-white/20 transition"
        style="-webkit-app-region: no-drag"
        title="全部关闭（Esc）"
        @click="dismissAll"
      >
        ✕
      </button>
    </div>

    <div class="flex-1 overflow-y-auto p-3 space-y-2">
      <div
        v-for="n in items"
        :key="n.id"
        class="flex items-center gap-2 p-2 rounded-md bg-amber-50 dark:bg-neutral-700/60"
      >
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium truncate dark:text-neutral-100">{{ n.title }}</p>
          <p class="text-xs text-neutral-400">{{ fmt(n.remindAt) }}</p>
        </div>
        <button
          class="shrink-0 px-2.5 py-1 text-xs rounded-md bg-amber-500 text-white hover:bg-amber-600 active:scale-95 transition"
          @click="open(n.id)"
        >
          打开笔记
        </button>
      </div>
    </div>

    <div class="px-3 py-2 border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
      <span class="text-xs text-neutral-400">窗口不会自动关闭</span>
      <button
        class="px-3 py-1 text-sm rounded-md text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
        @click="dismissAll"
      >
        全部知道了
      </button>
    </div>
  </div>
</template>
