import { createApp } from 'vue'
import QuickApp from './QuickApp.vue'
import './style.css'

const savedTheme = localStorage.getItem('shinian-theme')
if (
  savedTheme === 'dark' ||
  (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)
) {
  document.documentElement.classList.add('dark')
}

createApp(QuickApp).mount('#app')
