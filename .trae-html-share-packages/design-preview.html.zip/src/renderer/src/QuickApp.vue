<script setup>
import { ref, onMounted } from 'vue'

const text = ref('')
const inputRef = ref(null)

// 主窗口切换主题后，速记窗下次显示时同步
function syncTheme() {
  document.documentElement.classList.toggle(
    'dark',
    localStorage.getItem('shinian-theme') === 'dark'
  )
}

async function submit() {
  const content = text.value.trim()
  if (content) {
    await window.quickApi.submit(content)
  }
  text.value = ''
  await window.quickApi.hide()
}

function onKeydown(e) {
  if (e.key === 'Escape') {
    window.quickApi.hide()
  } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    submit()
  }
}

onMounted(() => {
  inputRef.value?.focus()
  // 每次窗口重新显示（获得焦点）时，光标回到输入框，并同步最新主题
  window.addEventListener('focus', () => {
    syncTheme()
    inputRef.value?.focus()
  })
})
</script>

<template>
  <div class="h-screen flex flex-col bg-white rounded-lg overflow-hidden border border-amber-300/60 shadow-xl dark:bg-neutral-800 dark:border-amber-500/30">
    <div
      class="px-3 py-2 bg-gradient-to-r from-amber-400 to-amber-500 text-white text-xs flex items-center justify-between select-none"
      style="-webkit-app-region: drag"
    >
      <span class="font-semibold tracking-wide">拾念 · 速记</span>
      <span class="text-amber-100">Ctrl+Enter 保存 · Esc 关闭</span>
    </div>
    <textarea
      ref="inputRef"
      v-model="text"
      class="flex-1 w-full p-3 resize-none outline-none text-base leading-6 bg-transparent dark:text-neutral-200"
      placeholder="此刻在想什么？"
      @keydown="onKeydown"
    ></textarea>
  </div>
</template>
